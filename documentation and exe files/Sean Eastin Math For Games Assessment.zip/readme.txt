How to run the program

open .exe file





keyboard
controls

player 1

movement is WASD
to rotate the turret use q and e
to fire use space


player 2

movement is ijkl
to rotate the turret use u and o
to fire use enter





Known Bugs

tanks will drift if you attempt to rotate while moving

if hitboxes are shown then you will see that sometimes hitboxes can still be triggered even though the player has been removed